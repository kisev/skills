Alpha reference.
