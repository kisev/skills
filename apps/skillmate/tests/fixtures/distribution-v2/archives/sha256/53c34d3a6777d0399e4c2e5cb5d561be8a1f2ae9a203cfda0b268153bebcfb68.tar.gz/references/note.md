Alpha reference v2.
